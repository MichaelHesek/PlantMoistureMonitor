namespace PlantMoistureMonitor.Core.Interfaces
{
    public interface IPlantMonitorService
    {
        Task RunAsync();
    }
}
